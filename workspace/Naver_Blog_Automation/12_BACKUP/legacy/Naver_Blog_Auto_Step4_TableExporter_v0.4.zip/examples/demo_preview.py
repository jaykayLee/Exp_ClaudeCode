"""Run offline; no real product prices or links are queried."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from exporters.table_exporter import export_product_table


@dataclass
class DemoProductResult:
    query: str
    danawa_price: int | None = None
    danawa_url: str | None = None
    naver_price: int | None = None
    naver_url: str | None = None
    image_path: str | None = None


def main() -> None:
    records = [
        DemoProductResult("샘플 제품 A", 123400, "https://example.com/danawa/a", 122900,
                          "https://example.com/naver/a", "examples/sample_images/sample_demo.png"),
        DemoProductResult("샘플 제품 B (부분 실패)", 99000, "https://example.com/danawa/b",
                          None, None, None),
        DemoProductResult("샘플 제품 C", None, None, 72000, "https://example.com/naver/c", None),
    ]
    out = export_product_table(records, ROOT / "output" / "product_table_demo.html",
                               image_base_dir=ROOT, title="[데모] 상품 가격 비교표 — 실제 시세 아님")
    print(f"Created: {out}")
    print("All names/prices/links above are illustrative demo data, NOT live collection.")


if __name__ == "__main__":
    main()
