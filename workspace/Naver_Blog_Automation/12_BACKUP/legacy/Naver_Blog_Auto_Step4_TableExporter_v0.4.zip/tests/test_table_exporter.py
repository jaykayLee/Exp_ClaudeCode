from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace

from exporters.table_exporter import HEADERS, export_product_table, render_product_table


class TableReader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_th = False
        self.headers = []
        self.td_count = 0

    def handle_starttag(self, tag, attrs):
        if tag == "th":
            self.in_th = True
        elif tag == "td":
            self.td_count += 1

    def handle_endtag(self, tag):
        if tag == "th":
            self.in_th = False

    def handle_data(self, data):
        if self.in_th:
            self.headers.append(data)


class ExportTests(unittest.TestCase):
    def test_headers_rows_price_and_safe_link(self):
        products = [
            {"query": "노트북 <script>alert(1)</script>", "danawa_price": 129000,
             "danawa_url": "https://example.com/?a=1&b=2", "naver_price": None,
             "naver_url": "javascript:alert(1)", "image_path": "does-not-exist.jpg"},
            SimpleNamespace(query="마우스", danawa_price=None, naver_price=10000,
                            naver_url="https://example.com/mouse", image_path=None),
        ]
        html = render_product_table(products)
        p = TableReader()
        p.feed(html)
        self.assertEqual(p.headers, list(HEADERS))
        self.assertEqual(p.td_count, 14)
        self.assertIn("129,000원", html)
        self.assertIn("10,000원", html)
        self.assertIn("&lt;script&gt;", html)
        self.assertNotIn("<script>", html)
        self.assertNotIn('href="javascript:', html)
        self.assertIn("이미지 없음", html)

    def test_embedded_image_and_write(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temp:
            file = export_product_table([
                {"query": "제품", "image_path": "examples/sample_images/sample_demo.png"}
            ], Path(temp) / "nested" / "table.html", image_base_dir=root)
            html = file.read_text(encoding="utf-8")
            self.assertIn("data:image/png;base64,", html)
            self.assertTrue(file.is_file())


if __name__ == "__main__":
    unittest.main()
