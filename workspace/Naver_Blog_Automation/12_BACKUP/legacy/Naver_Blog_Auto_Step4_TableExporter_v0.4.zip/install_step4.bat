@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 --version
  echo Step 4 exporter requires no additional pip packages.
  pause
  exit /b 0
)
where python >nul 2>nul
if %errorlevel%==0 (
  python --version
  echo Step 4 exporter requires no additional pip packages.
  pause
  exit /b 0
)
echo Python 3 not found. Install Python for Windows and try again.
pause
exit /b 1
