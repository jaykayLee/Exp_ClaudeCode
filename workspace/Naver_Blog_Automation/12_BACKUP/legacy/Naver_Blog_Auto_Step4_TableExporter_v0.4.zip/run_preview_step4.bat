@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m unittest discover -s tests -v
  if errorlevel 1 goto fail
  py -3 examples\demo_preview.py
  if errorlevel 1 goto fail
  goto open
)
where python >nul 2>nul
if %errorlevel%==0 (
  python -m unittest discover -s tests -v
  if errorlevel 1 goto fail
  python examples\demo_preview.py
  if errorlevel 1 goto fail
  goto open
)
goto fail
:open
start "" "output\product_table_demo.html"
exit /b 0
:fail
echo Test or preview generation failed.
pause
exit /b 1
