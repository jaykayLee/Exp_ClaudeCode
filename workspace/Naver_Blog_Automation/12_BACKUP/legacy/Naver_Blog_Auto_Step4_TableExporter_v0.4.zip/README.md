# Naver Blog Auto — Step 4 / Table Exporter v0.4

## Purpose
This package **adds only the offline, 7-column product table exporter**. It does not replace previous Danawa/NaverShopping collectors or the image resizer. It does not post to Naver Blog.

Required headers, in exact order:

`No. | 상품명 | 이미지 | 다나와 최저가 | 사이트 주소 | 네이버 최저가 | 사이트 주소`

Inputs are `ProductResult`-compatible objects or dictionaries containing:
`query, danawa_price, danawa_url, naver_price, naver_url, image_path`.

## Windows: quick QA (without running any live collection)

1. Unzip with Windows Explorer.
2. Double-click `install_step4.bat` to verify Python 3. No extra packages are needed for this step.
3. Double-click `run_preview_step4.bat` to execute tests and open `output/product_table_demo.html`.
4. The included product names/prices/links are **fictional sample values**. They are not real-time data.

## Integration into the existing project

Only copy `exporters/` into your existing `naver_blog_auto` folder. Preserve your existing collectors, model, configs, and installation scripts.

```python
from pathlib import Path
from exporters.table_exporter import export_product_table
from services.price_compare import collect_product_prices

names = ["로지텍 MX Master 3S", "LG 그램 16", "아이폰 16 128GB"]
products = [collect_product_prices(name) for name in names]
# After your Step 3 image service, assign each product.image_path to the
# existing resized image path (DO NOT download or resize in the exporter).
output_path = export_product_table(
    products, output_file=Path("output/product_table.html"),
    image_base_dir=Path.cwd(),
)
print(output_path)
```

If the image service has not yet populated `image_path`, the preview shows `이미지 없음` and still creates all 7 columns. If a price is absent/not integer, it shows `미수집`. URLs accept only http/https and are escaped in HTML. The HTML contains base64-embedded **local resized** JPG/PNG/WebP files up to 5 MiB each for a portable local preview. Blog editor upload and post-writing must be handled separately; do not assume base64 images can be published directly.

## QA conditions

- Seven header strings match exactly, including the duplicated `사이트 주소` headers.
- One row per product and automatic 1-based `No.` sequence.
- Prices are numeric source `int` or missing (not scraped formatted text).
- One or both price sources may fail without dropping the row.
- Existing local resized image, missing image, and invalid URL handled safely.
- All tests pass offline with `python -m unittest discover -s tests -v`.

## Next step (not implemented here)

Separate Naver Blog editor interaction, real image upload, draft verification, and publication gating from the local exporter. First verify editor support and terms; no unattended publishing is implemented.
