"""Offline snapshot probe package."""
